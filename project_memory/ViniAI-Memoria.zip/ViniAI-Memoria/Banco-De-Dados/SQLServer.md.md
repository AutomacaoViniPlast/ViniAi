# SQL Server — METABASE

## Conexão

| Campo           | Valor                                                                                  |
| --------------- | -------------------------------------------------------------------------------------- |
| Host            | 192.168.1.83                                                                           |
| Porta           | 50172                                                                                  |
| Banco           | METABASE                                                                               |
| Usuário         | sa                                                                                     |
| Driver          | ODBC Driver 17 for SQL Server                                                          |
| Variável `.env` | `MSSQL_HOST`, `MSSQL_PORT`, `MSSQL_DB`, `MSSQL_USER`, `MSSQL_PASSWORD`, `MSSQL_DRIVER` |

> [!warning] Uso exclusivo
> Este banco é usado **SOMENTE** para consultas de dados industriais.
> Nenhum dado de autenticação, conversa ou usuário vai aqui.

---

## Arquivos de Serviço

| Arquivo | Tabela/View | Status |
|---------|-------------|--------|
| `app/sql_service_sh6.py` | `dbo.STG_PROD_SH6_VPLONAS` | **Ativo** — produção das extrusoras |
| `app/sql_service_kardex.py` | `dbo.V_KARDEX` | **Implementado** — LD, TES, TURNO, LOTE (integração no orchestrator pendente) |

---

## Tabelas / Views

### dbo.STG_PROD_SH6_VPLONAS — apontamentos de produção (ativa)

Tabela principal para consultas de produção das extrusoras MAC1 e MAC2.

| Coluna | Tipo | Descrição |
|--------|------|-----------|
| FILIAL | varchar | 010101=VINIPLAST, 010201=Confecção |
| OP | varchar | Ordem de produção (gerada pelo PCP) |
| PRODUTO | varchar | Código do produto — primeiros 3 chars = tipo |
| RECURSO | varchar | 0003=Extrusora1/MAC1, 0007=Extrusora2/MAC2, 0005=Revisão, 0006=Revisão2 |
| NOME_USUARIO | varchar | Nome completo ou login do operador |
| DATA_APONT | date | Data do apontamento — usar para filtros **mensais** |
| DATA_INI | date | Data de início — usar para filtros **diários** |
| PESO_FILME_PASSADA | float | Peso produzido em KG |
| QTDPROD2 | float | Metros produzidos |
| MINUTOS | float | Minutos trabalhados |
| KGH | float | Coluna direta — NÃO usar diretamente, calcular via fórmula |

**Regras de negócio SH6:**
- Produção mensal → `SUM(PESO_FILME_PASSADA)` filtrado por `DATA_APONT`
- Produção diária → `SUM(PESO_FILME_PASSADA)` filtrado por `DATA_INI` (quando ini == fim)
- Metros/min → `SUM(QTDPROD2) / SUM(MINUTOS)`
- KGH → `SUM(PESO_FILME_PASSADA) / (SUM(MINUTOS) / 60)` — nunca AVG(KGH)
- Filial padrão → `010101` quando não especificada
- Recurso padrão → `('0003', '0007')` — exclui Revisão automaticamente

---

### dbo.V_KARDEX — view de movimentação de materiais

Representa movimentações industriais: produção, revisão e movimentação interna.
Implementada em `app/sql_service_kardex.py`.

**Quando usar:** request envolver OP, TURNO, TES, qualidade Y/I, LOTE ou detalhamento de movimentação.

| Coluna | Tipo | Descrição |
|--------|------|-----------|
| FILIAL | varchar | 010101=VINIPLAST, 010201=VINITRADE INDUSTRIA E COMERCIO LTDA |
| ORIGEM | varchar | SD1, SD2, SD3 — filtro opcional |
| EMISSAO | date | Data de emissão — campo principal de filtro por período |
| TES | varchar | Tipo de movimentação (ver mapa abaixo) |
| PRODUTO | varchar | Código do produto — ver parse_produto() |
| DESCRICAO | varchar | Descrição completa do material |
| LOTE | varchar | Sequência gerada ao lançar bobina na produção |
| QUANTIDADE | float | Total produzido/movimentado — **TES 999 retorna negativo** (lógica de saldo pendente) |
| USUARIO | varchar | Operador que registrou o movimento |
| LOCAL_OP | varchar | Localização: 'EXTRUSAO'=produção. Outros valores pendentes de mapeamento |
| TURNO | varchar | Turno — filtrar somente quando explicitamente solicitado |
| RECURSO | varchar | 0003=Extrusora1/MAC1, 0007=Extrusora2/MAC2 |
| QUALIDADE | varchar | Y=LD, I=Inteiro (equivalente à posição 5 do PRODUTO) |

**Mapa de TES:**

| Código | Significado |
|--------|-------------|
| `499` | Movimentação interna de entrada (entrada de estoque) |
| `999` | Movimentação interna de saída |
| `502` | Inconsistência XML (CNPJ, IE, Data, Modelo, Série, Número ou Tipo Emissão) |
| `010` | **Bloqueada no código** — significado pendente de mapeamento |

**Regras de negócio V_KARDEX:**
- Filial padrão → `010101`
- LOCAL_OP → sempre filtrar por `'EXTRUSAO'` em consultas de produção/soma
- TURNO → NÃO filtrar salvo solicitação explícita do usuário
- TES 010 → bloqueada — não exposta mesmo se solicitada
- `parse_produto()`: pos 1-3=código-base, pos 5=Y/I, pos 6-8=cor1, pos 11-13=cor2

> [!warning] Pendências V_KARDEX
> - LOCAL_OP: mapear outros valores além de 'EXTRUSAO'
> - QUANTIDADE negativa (TES 999): confirmar lógica de saldo antes de implementar somatórios mistos
> - Roteamento: confirmar regra completa V_KARDEX vs SH6
> - Integração no orchestrator ainda não feita

---

### dbo.STG_PROD_SD3 — movimentação interna
Pendente de integração.

### dbo.STG_APONT_REV_GERAL — apontamentos de revisão
Pendente de mapeamento de colunas.

---

## Estrutura do Código de Produto

```
Exemplo: CLILA0600L0400A
  CLI   → código-base do produto (pos 1-3) — tabela de tipos pendente
  L     → variante (pos 4)
  A     → qualidade (pos 5): Y=LD, I=Inteiro
  0600  → cor 1 (pos 6-8 + extra)
  L     → separador
  0400  → cor 2 (pos 11-13 + extra)
  A     → sufixo
```

Função `parse_produto()` em `sql_service_kardex.py` extrai: `codigo_base`, `tipo_material`, `cor_1`, `cor_2`.

---

## Regras de Query (pyodbc)

```sql
-- Sempre limpar espaços
LTRIM(RTRIM(USUARIO))

-- Parâmetros: usar ? (pyodbc), NUNCA %s
WHERE EMISSAO BETWEEN ? AND ?

-- Case-insensitive
LOWER(col) LIKE LOWER(?)
-- ou UPPER(col) para LOCAL_OP

-- Paginação: TOP N, nunca LIMIT
SELECT TOP 5 ...

-- Datas: tipos date nativos — sem conversão de texto
-- Python: datetime.strptime(date_str, "%d/%m/%Y").date()

-- Filtro por ORIGEM é sempre opcional (muitos registros têm NULL)
```

---

## Conceitos de Negócio

> [!warning] Não confundir
> - **Produção** = material que saiu da extrusora (recursos 0003 e 0007)
> - **Revisão** = inspeção do material após extrusão. Recursos 0005 e 0006. Identifica LD (Y) ou Inteiro (I)
> - **Expedição** = liberação de bobinas para clientes. **NUNCA** entra em ranking de produção

---

## Links relacionados

- [[Arquitetura-Geral]] — contexto do banco na arquitetura
- [[Agentes]] — quem consulta este banco
- [[Interpretacao-de-Intencao]] — como as queries são geradas
